# Kaggle_Comps
Hosts data and scripts for my kaggle competitions
