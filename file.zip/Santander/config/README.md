Here you'll store any configurations settings for your project. Use the DCF format that the `read.dcf()` function parses.
