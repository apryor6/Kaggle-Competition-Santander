# Data

Since the `train_ver2.csv` file is 2.2 GB I kept it in a local folder at: 
`~Documents/Data/Kaggle_Comps/Santander/`. 

The [competition page](https://www.kaggle.com/c/santander-product-recommendation/data)
has the following description about the data:

> In this competition, you are provided with 1.5 years of customers behavior data from Santander bank to predict what new products customers will purchase. The data starts at 2015-01-28 and has monthly records of products a customer has, such as "credit card", "savings account", etc.

