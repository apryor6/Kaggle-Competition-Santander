AJ's `santander-cleaning.Rmd` script can be viewed here https://www.kaggle.com/apryor6/santander-product-recommendation/detailed-cleaning-visualization


Here is an easy way to knit documents
    ezknitr::ezspin(wd = "~/Documents/Kaggle_Comps", file = "Santander/munge/data_doc.R", fig_dir = "../graphs/", keep_md = T, keep_html = F, out_dir = "Santander/doc/")